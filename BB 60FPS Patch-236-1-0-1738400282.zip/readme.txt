You must supply your own decrypted copy of eboot.bin from version 1.09 of the game. Any region is fine.
Put the .exe files supplied into the same folder as your copy of eboot.bin.

If you want to play the game at 720p60fps, run 720p.exe to apply that patch to the game (Highly recommended version!)
If you want to play the game at 1080p60fps, run 1080p.exe to apply that patch to the game (Not recommended for 8the generation consoles, maybe useful in the future though!)

Your eboot.bin file has been patched, enjoy your game.

This was made with love by Lance McDonald